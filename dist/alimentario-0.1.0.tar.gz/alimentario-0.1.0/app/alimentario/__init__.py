__version__= "0.1.0"

from .src.alimentario import *